#include "linked_calc.hpp"
#include <iostream>
#include <string>
using namespace std; 

// Default constructor definition
template <typename T>
LinkedCalc<T>::LinkedCalc() : head(nullptr) {}

// Destructor to deallocate memory
template <typename T>
LinkedCalc<T>::~LinkedCalc() {
    Node <T>* current = head;
    while (current != nullptr){
        Node<T>* temp = current;    //temp = current 
        current = current->next;  //move current
        delete temp;    //free temp memory
    }
}

// Function to insert a new node at the end of the linked list
template <typename T>
void LinkedCalc<T>::insert(const T& value) {
    Node<T>* newNode = new Node<T>(value);
    if (head == nullptr) {
        head = newNode;
    } 
    else{
        Node<T>* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = newNode;
    }
}

// Helper function to determine if a character is a digit
template <typename T>
bool LinkedCalc<T>::isDigit(const T& c) {
    return (c >= '0' && c <= '9') ;
}

//Note: Stringtofloat and floattoString are included in header for the sake of being concise in the cpp. 

//=======================================================================================================================================================================
//Function to validate expression
//=======================================================================================================================================================================
template <typename T>
bool LinkedCalc<T>::validateExpression(){
    Node<T> *current = head;
    std::string lastState = "None"; // initializing string lastState to track last state
    bool decimalPoint = false; // tracking if a decimal point has been seen in the current number

    while (current != nullptr){ //continuing until we reach end
        // ----------------------------------Digit----------------------------------------------------------------------
        if (isDigit(current->data)){       //if number is a digit
            lastState = "Digit"; // updates lastState to digit
        }
        // --------------------------------Operator------------------------------------------------------------------------
        else if (current->data == '*' || current->data == '/' || current->data == '+' || current->data == '-'){
            if (lastState != "Digit"){
                // invalid becuase digit didnt come before operator
                return false;
            }
            lastState = "Operator"; // otherwise update lastState to Operator
            decimalPoint = false; // resetting decimal point tracking for next number group
        }
        // ---------------------------------Decimal-----------------------------------------------------------------------
        else if (current->data == '.'){
            if (lastState != "Digit" || decimalPoint){
                // invalid becuase digit didnt come before the decimal 
                return false;
            }
            lastState = "Decimal Point"; // otherwise updating lastState to decimal point
            decimalPoint = true;    //setting decimal point to true
        }
        // ------------------------------- Anything else---------------------------------------------------------------------------
        else{
            return false; // anything leftover is an invalid char 
        }
        current = current->next; // traversing through list
    }

    // at end of list, we need to ensure it ends with a digit and not an operator or decimal, if not, it is invalid
    if (lastState != "Digit"){
        return false;
    }
    // if we run with no issues, we make it to this point and can return true.
    return true;
}

//=======================================================================================================================================================================
// Function to evaluate the expression represented by the linked list
//=======================================================================================================================================================================
template <typename T>
float LinkedCalc<T>::evaluateExpression(){
    Node<T>* current = head; //current points to head
    Node<T>* temp1 = nullptr;   //TEMP1 is null right now
    float value = 0.0;      //initializing value (float)

// First pass: Handle multiplication and division
    while (current != nullptr && current->next != nullptr){ //loop through the list while current next node != null
        if (current->next->data == '*' || current->next->data == '/'){
            std::string leftStr = "";           //initialize empty string for lhs num
            Node<T>* lhsNode = current;  // we need to assign lhs num to current

            while (lhsNode != nullptr && (isdigit(lhsNode->data) || lhsNode->data == '.')){  //loop to get left num  
                leftStr += lhsNode->data;   //adding lhs num to lhs string
                lhsNode = lhsNode->next; //updating lhsNode to now point to the operator
            }
            float leftOperand = stringToFloat(leftStr); //need to turn lhs string to float now
            char oper = lhsNode->data;  //assigning the operator to oper that way now we know how to handle the digits (mul or div)
            lhsNode = lhsNode->next; //moving from operator to next digit

            // now we need to assign rhs to string
            std::string rightStr = "";  //empty string for rhs string
            while (lhsNode != nullptr && (isdigit(lhsNode->data) || lhsNode->data == '.')){  //loop to collect the right operan
                rightStr += lhsNode->data; //since lhs was updated to point to the right num, here we are adding rhs num to rhs string
                lhsNode = lhsNode->next;    //now lhsNodeis updated to next node
            }
            float rightNumber = stringToFloat(rightStr);    //need to convert rhs string to float

            // operations * and /
            if (oper == '*'){  //now we can finally perform the operations after all the conversions
                value = leftOperand * rightNumber;  
            } 
            else if (oper == '/'){
                value = leftOperand / rightNumber;
            }

            // convert result to back to string and create new nodes
            std::string resultStr = floatToString(value);
            Node<T>* newHead = nullptr;
            Node<T>* newTail = nullptr;

            for (char x : resultStr){ // loop through each character in resultStr
                Node<T>* newNode = new Node<T>(x);  //new node for each character
                if (newHead == nullptr){//If newHead is nullptr, it means this is the first node being added to the new list
                    newHead = newNode;  //set newHead to first new node
                    newTail = newNode;  //set newTail to first new node
                } 
                //If newHead is not a nullptr, it means there are already nodes in it and new node is added to the end of list 
                else{
                    newTail->next = newNode; //having newTail next point to newNode. Adds newNode to the end of the linked list.
                    newTail = newNode; //newTail now points to new node. Now, newTail points to the last node in the linked list.
                }
            }

            // replacing the operator and second num with result
            newTail->next = lhsNode; // connects the newTail to the remainder of the original linked list

            if (current != head){
                temp1->next = newHead; // adjusting the previous operator's next to point to the new result
            } else{
                head = newHead; // update head if no previous operator
            }
            current = newTail; // setting current to the newResultTail to continue 
        } else{
            temp1 = current; //setting temp1 to current
            current = current->next; //move to the next node
        }
    }

    // Second pass: Handle addition and subtraction
    float total = 0.0f;
    char lastOper = '+';  // Initialize lastOper to '+'
    current = head; //current points to head

    while (current != nullptr){
        if (isdigit(current->data) || current->data == '.'){ //if num or decimal point
            std::string numStr = "";    //creating empty string
            while (current != nullptr && (isdigit(current->data) || current->data == '.')){ // looping to get number
                numStr += current->data; //add num to numStr
                current = current->next; //move to next node
            }

            float num = stringToFloat(numStr); //converting to float

            if (lastOper == '+'){ //since + was already initialized, we will check to see if it is a +
                total += num;
            } else if (lastOper == '-'){
                total -= num;
            }
        } else{
            lastOper = current->data; //otherwise if not +,  update lastOper to current operator
            current = current->next; //go to next node
        }
    }
    return total;
}
