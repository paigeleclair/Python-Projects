#ifndef LINKED_CALC_HPP
#define LINKED_CALC_HPP

#include <iostream>

// Node structure
template <typename T>
struct Node {
    T data;
    Node* next;

    Node(const T& data) : data(data), next(nullptr) {}
};

// LinkedCalc class
template <typename T>
class LinkedCalc {
public:
    LinkedCalc();
    ~LinkedCalc();
    void insert(const T& value);
    bool validateExpression();
    float evaluateExpression();
    float stringToFloat(const std::string& str);
    std::string floatToString(float value); // Declaration of the floatToString function



private:
    Node<T>* head;
    bool isDigit(const T& c);
};

//Float to String helper function
template <typename T>
std::string LinkedCalc<T>::floatToString(float value) {
    std::string result; // initialize empty string 

    // Convert integer part
    int wholenum = value; 
    float decimalPart = value - wholenum; // calculating decimal part
    std::string integerStr; // initialize  empty string

    while (wholenum > 0) {
    integerStr += '0' + (wholenum % 10); // use modulus to get last digit and add it to the string
    wholenum = wholenum / 10; // Remove the last digit from the integer part
}

    //reversing the integer part
    int i = 0;
    int j = integerStr.size() - 1;
    while (i < j) {
        char temp = integerStr[i]; // store char at position i in a temp variable
        integerStr[i] = integerStr[j]; // Assign j to i
        integerStr[j] = temp; // Assign temp to position j
        ++i; // increment i
        --j; // decrement j
    }
    result += integerStr; // result = result + integer string

    // convert fractional part
    if (decimalPart > 0) { // check if there is a decimal part
        result += '.'; // Add decimal point to the result string
        for (int i = 0; i < 6; ++i) { // Limit to 6 decimal places
            decimalPart *= 10; // Shift the decimal point to the right
            int digit = static_cast<int>(decimalPart); // Extract the next digit
            result += '0' + digit; // Add the digit to the result string
            decimalPart -= digit; // Remove the digit from the fractional part
        }
    }
    return result; // Return the final result string
}

// Function to convert a string to a float without using any library functions
template <typename T>
float LinkedCalc<T>::stringToFloat(const std::string& str) {
    float result = 0.0f; // Initialize the result to 0
    float decimalFactor = 0.1f; // Factor for decimal places
    bool isDecimal = false; // Flag to indicate if a decimal point has been encountered
    size_t i = 0; // Index for iterating through the string
    for (; i < str.length(); ++i) { // Iterate through each character in the string
        char z = str[i]; // Get the current character
        if (z == '.') { // Check if the character is a decimal point
            if (isDecimal) { // If a decimal point has already been encountered
                return 0.0f; // Return 0.0f as multiple decimal points are not allowed
            }
            isDecimal = true; // Set the flag to indicate a decimal point has been encountered
        } 
        else if (z >= '0' && z <= '9') { // Check if the character is a digit
            if (isDecimal) { // If processing the decimal part
                result += (z - '0') * decimalFactor; // Add the digit to the result
                decimalFactor *= 0.1f; // Update the decimal factor
            } 
            else { // If processing the integer part
                result = result * 10 + (z - '0'); // Add the digit to the result
            }
        }
    }
    return result; // Return the final result
}

#endif // LINKED_CALC_HPP
