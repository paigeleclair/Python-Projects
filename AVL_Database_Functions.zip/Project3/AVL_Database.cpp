// AVL_Database.cpp
#include "AVL_Database.hpp"
#include <algorithm>
#include <cmath>

Record::Record(const std::string& k, int v) : key(k), value(v) {}

AVLNode::AVLNode(Record* r) : record(r), left(nullptr), right(nullptr), height(1) {}

AVLTree::AVLTree() : root(nullptr), nodeCount(0), searchComparisonCount(0) {}

int AVLTree::height(AVLNode* node) {
    return node ? node->height : 0;
}

void AVLTree::updateHeight(AVLNode* node) {
    if (node) {
        node->height = 1 + std::max(height(node->left), height(node->right));
    }
}

int AVLTree::getBalance(AVLNode* node) {
    return node ? height(node->left) - height(node->right) : 0;
}

/*
Can be used to balance AVL trees
*/
/////////////////////////////////////////Rotating/////////////////////////////////////////////////////////////
AVLNode* AVLTree::rotateRight(AVLNode* y) {
    AVLNode* temp1 = y->left; // setting temp1 to y's left child
    AVLNode* temp2 = temp1->right;  // temp2 is temp1's right
    temp1->right = y; //now y is the right child of temp1
    y->left = temp2; //temp2 is the left child of y
    updateHeight(y);  //updating the heights of y and temp1
    updateHeight (temp1);
    return temp1; //returning the new root of rotated tree
}


AVLNode* AVLTree::rotateLeft(AVLNode* x) {
    AVLNode* temp1 = x->right; //setting the right child of x to temp1
    AVLNode* temp2 = temp1->left; //setting the left child of temp1 to temp2
    temp1->left = x; //reasssigning temp1's left child to be x
    x->right = temp2; // and x's right child is now temp2
    updateHeight(x); //updating the hieghts of x and temp1
    updateHeight(temp1); 
    return temp1; //returning the new root of rotated teee
}

////////////////////////////Inserting //////////////////////////////////////////
void AVLTree::insert(Record* record) {
    if (!record){ //if null node dont add
        return; 
    }
    root = insertHelper(root, record); //otherwise call the helper function to insert
}
AVLNode* AVLTree::insertHelper(AVLNode* node, Record* record) {
    if (!node) { // if the node is null....
        nodeCount++; //increment node count and create a new avl node
        return new AVLNode(record);
    }
    if (record->value < node->record->value){ // if the record value is less than the node's record value....
        node->left = insertHelper(node->left, record); // insert in the left subtree
    } 
    else if (record->value > node->record->value){ // if the record value is greater than the node's record value...
        node->right = insertHelper(node->right, record); // insert in the right subtree
    } 
    else{  // if the record value is equal to the node's record value...
        return node; // return the node since we dont want to insert duplicates
    }
    updateHeight(node); // update height of current
    int balance = getBalance(node);  // get balance factor of current


    //RIGHT rotation
    if (balance > 1 && record->value < node->left->record->value){ //if node left-leaning & record val < left child's record value
        return rotateRight(node); //perform right rotation
    }
    //LEFT ROTATION
    if (balance < -1 && record->value > node->right->record->value){ // // if node is right-leaninf & record value > right child's record value
        return rotateLeft(node); //preform left rotation
    }
    //LEFT-RIGHT
    if (balance > 1 && record->value > node->left->record->value){ //if node is left-leaning and the record value > left child's record value
        node->left = rotateLeft(node->left); //perform left-right rotation (left)
        return rotateRight(node); // (right)
    }
    //RIGHT-LEFT
    if (balance < -1 && record->value < node->right->record->value){ //if node is right-leaning and the record value < right child's record value
        node->right = rotateRight(node->right); //preform right-left rotation (right)
        return rotateLeft(node); //(left)
    }
    // if we made it this far, return the root of the subtree
    return node;
}


AVLNode* AVLTree::minValueNode(AVLNode* node) {
    AVLNode* current = node; // setting current to passed node
    while (current->left){ // looping to find leftmost leaf
        current = current->left;
    }
    return current; // returning  leftmost leaf
}

//////////////////////////////////////////DELETING/////////////////////////////////////
void AVLTree::deleteNode(const std::string& key, int value) {
    root = deleteHelper(root, key, value); //simply calling delete helper, passing the root, key, and value
}

AVLNode* AVLTree::deleteHelper(AVLNode* node, const std::string& key, int value) {
    if (!node){ // if node is null...
        return node; // return node
    }
    if (value < node->record->value){ // if value is less than node's value...
        node->left = deleteHelper(node->left, key, value);  //go to left subtree
    } 
    else if (value > node->record->value){ //if value is greater than node's value, 
        node->right = deleteHelper(node->right, key, value); //go to right subtree
    }
    else{ // otheerwise, if value is equal to node's value, then we delete this node
        if (!node->left || !node->right){ // if node has one or no children
            AVLNode* temp = node->left ? node->left : node->right; // getting non-null child
            if (!temp){ // if no children...
                temp = node; node = nullptr; //set node to null
            } 
            else{ // if one child...
                *node = *temp;  //copy child to node
            } 
            delete temp->record; // deleting the record of temp
            delete temp; // deleting temp
            nodeCount--; // decrement node count
        } 
        else{ // if node has two children....
            AVLNode* temp = minValueNode(node->right); // get the smallest in the right subtree (succusser)
            node->record = temp->record; // copy it to this node
            node->right = deleteHelper(node->right, temp->record->key, temp->record->value); // delete successor
        }
    }
    if(!node){  // if node is null after deletion....
        return node; // return node
    }
    updateHeight(node); // updating height of the current node
    int balance = getBalance(node); // geting the balance factor of the current node
    // left left 
    if (balance > 1 && getBalance(node->left) >= 0){ 
         return rotateRight(node); // right rotation
    } 
    // left right
    if (balance > 1 && getBalance(node->left) < 0){
        node->left = rotateLeft(node->left); //  left rotation first on left child
        return rotateRight(node); //  right rotation
    } 
    // right right 
    if (balance < -1 && getBalance(node->right) <= 0){
        return rotateLeft(node); // left rotation
    } 
    //right left
    if (balance < -1 && getBalance(node->right) > 0){ 
        node->right = rotateRight(node->right); //  right rotation first on right child
        return rotateLeft(node); // left rotation
    }
    return node; // returning root of subtree
}

//////////////////////////////////////SEARCHING////////////////////////////////////////
Record* AVLTree::search(const std::string& key, int value) {
    searchComparisonCount = 0;  // initializing search comparison count to 0
    AVLNode* result = searchHelper(root, key, value); // helper function to search for node
    if (result){ // if that result exists in the search...
        return result->record;  // return it
    } 
    else{
        return new Record("", 0); // otherwise, we return new record with default key and value
    }
}
AVLNode* AVLTree::searchHelper(AVLNode* node, const std::string& key, int value) const {
    if (!node){ // if node is null
        return nullptr; // return nullptr
    }
    searchComparisonCount++; // increment comparison count
    if (value < node->record->value){ // if value < node's value,
        return searchHelper(node->left, key, value); // search in  left subtree
    }
    else if (value > node->record->value){ // if value > node's value
        return searchHelper(node->right, key, value); // search in the right subtree
    }
    else{ //otherwise, if value = node's value
        return node; //return the node
    }
}

// IndexedDatabase Implementation
void IndexedDatabase::insert(Record* record) {
    index.insert(record);
}
Record* IndexedDatabase::search(const std::string& key, int value) {
    return index.search(key, value);
}
void IndexedDatabase::deleteRecord(const std::string& key, int value) {
    index.deleteNode(key, value);
}
std::vector<Record*> IndexedDatabase::rangeQuery(int start, int end) {
    std::vector<Record*> result; // create empty vector to store results
    rangeQueryHelper(index.root, start, end, result); // call helper function to perform range query
    return result; // return vector with the records within the range
}

void IndexedDatabase::rangeQueryHelper(AVLNode* node, int start, int end, std::vector<Record*>& result) const {
    if (!node) { // if the node is null...
        return; //return 
    }
    if (start <= node->record->value) { // if start <=  node's value
        rangeQueryHelper(node->left, start, end, result); // recursively call the left subtree
    }

    if (start <= node->record->value && node->record->value <= end) { // if the node's value is within the range
        result.push_back(node->record); // add the node's record to the result vector
    }

    if (node->record->value <= end) { // if the node's value <= end value
        rangeQueryHelper(node->right, start, end, result); // recursively call the right subtree
    }
}
 

//////////////////////////////////////////GIVEN HELPERS////////////////////////////////////////////////////////////////////
void IndexedDatabase::clearHelper(AVLNode* node) {
    if (!node) return;
    clearHelper(node->left);
    clearHelper(node->right);
    delete node->record;
    delete node;
}

void IndexedDatabase::clearDatabase() {
    clearHelper(index.root);
    index.root = nullptr;
}

int IndexedDatabase::calculateHeight(AVLNode* node) const {
    if (!node) return 0;
    return 1 + std::max(calculateHeight(node->left), calculateHeight(node->right));
}

int IndexedDatabase::getTreeHeight() const {
    return calculateHeight(index.root);
}

int IndexedDatabase::getSearchComparisons(const std::string& key, int value) {
    search(key, value);
    return index.getLastSearchComparisons();
}