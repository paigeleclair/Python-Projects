/***********************************************************************************
Paige Leclair
U81741571
Description: A program that  manages and tracks the guest list for a
local restaurant. Each group of guests is stored with phone number,
last name and first name, and party size. It uses header and source files to
communicate across files
***************************************************************/

//read_line.h header file
#ifndef READ_LINE_H

#define READ_LINE_H
int read_line(char str[], int n);

#endif