/***********************************************************************************
Paige Leclair
U81741571
Description: A program that  manages and tracks the guest list for a
local restaurant. Each group of guests is stored with phone number,
last name and first name, and party size. It uses header and source files to
communicate across files
***************************************************************/

//this is the MAIN PROGRAM 
#include <stdio.h>
#include "guest.h" //including the header file so it can communicate
#include "read_line.h" //including the header file so it can communicate

int main(void) {
  char code;
  struct guest *new_list = NULL;
  printf("Operation Code: a for adding to the list at the end, r for removing "
         "from the list, p for printing "
         "the list; q for quit.\n");
  for (;;){
    printf("Enter operation code: ");
    scanf(" %c", &code);
    while (getchar() != '\n') /* skips to end of line */
      ;
    switch (code) {
    case 'a':
      new_list = add_guest(new_list);
      break;
    case 'r': //remove case
      new_list = remove_guest(new_list);
      break;
    case 'p':
      print_list(new_list);
      break;
    case 'q':
      clear_list(new_list);
      return 0;
    default:
      printf("Illegal code\n");
    }
    printf("\n");
  }
}