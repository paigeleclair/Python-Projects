/***********************************************************************************
Paige Leclair
U81741571
Description: A program that  manages and tracks the guest list for a
local restaurant. Each group of guests is stored with phone number,
last name and first name, and party size. It uses header and source files to
communicate across files
***************************************************************/

//HEADER FILE containing the function declarations and prototypes for
//functions in guest.c
#ifndef GUEST_H

#include <string.h>
#define NAME_LEN 30
#define PHONE_LEN 20
struct guest {
  char phone[PHONE_LEN + 1];
  char last[NAME_LEN + 1];
  char first[NAME_LEN + 1];
  int party_size;
  struct guest *next;
};
struct guest *add_guest(struct guest *list);
void print_list(struct guest *list);
void clear_list(struct guest *list);
struct guest *remove_guest(struct guest *list);
int read_line(char str[], int n);
#endif