/***********************************************************************************
Paige Leclair
U81741571
Description: A program that  manages and tracks the guest list for a
local restaurant. Each group of guests is stored with phone number,
last name and first name, and party size. It uses header and source files to
communicate across files
***************************************************************/

//READ_LINE.c source file

#include <stdio.h>
#include <ctype.h>
#include "read_line.h" //include header file



int read_line(char str[], int n) {
  int ch, i = 0;
  while (isspace(ch = getchar()))
    ;
  str[i++] = ch;
  while ((ch = getchar()) != '\n') {
    if (i < n)
      str[i++] = ch;
  }
  str[i] = '\0';
  return i;
}