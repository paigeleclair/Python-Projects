#include "FileSystem.hpp"
#include <stdexcept>
#include <sstream>
#include <algorithm> 

FileSystemNode::FileSystemNode(std::string name, bool isDir) 
    : name(name), isDirectory(isDir), parent(nullptr) {}

FileSystemNode::~FileSystemNode() {
    for (auto child : children) {
        delete child;
    }
}
FileSystem::FileSystem() {
    root = new FileSystemNode("/", true);
    currentDirectory = root;
}
FileSystem::~FileSystem() {
    delete root;
}
void FileSystem::mkdir(const std::string& name) {
    if (find(name)){ //using find() helper see if there is a directory already under that name
        throw std::runtime_error("Directory already exists"); //if so we throw error
    }
    FileSystemNode* newDir = new FileSystemNode(name, true); //otherwise, we make newDir called of the input name
    newDir->parent = currentDirectory; //parent of the newDir will be the currentDirectory children
    currentDirectory->children.push_back(newDir); //pushing newDir to the children in currentdirectory
}

void FileSystem::touch(const std::string& name) {
    if (find(name)){ //again, using find() to see if file under that name exists in directory
        throw std::runtime_error("File already exists"); //if so throw error
    }
    FileSystemNode* newFile = new FileSystemNode(name, false); //otherwsie we create new file
    newFile->parent = currentDirectory; //set its parent to the children in current directory
    currentDirectory->children.push_back(newFile); //pushing newFile to the children list in Directory
}

std::string FileSystem::ls() {
    std::stringstream ss;
    for (auto child : currentDirectory->children){ //iterate through children of directory, setting each iteration to variable child
        ss << child->name; //adding name of file or directory
            if (child->isDirectory){ //if child isDirectory == true
                ss << "/";  //we add a '/'
            } 
            else{
                ss << ""; //otherwise, we add nothing
            }
            ss << " "; //adding a space at the end
    }
    return ss.str(); //converting ss to string and returning 
}

void FileSystem::cd(const std::string& path) {
    if (path == "/"){ //if our path is a '/'
        currentDirectory = root; //this is our root
        return; 
    }
    FileSystemNode* target;
    if (path[0] == '/'){ //If first is '/'
        target = root; //then we start from root
    } 
    else{
        target = currentDirectory; //otherwise, we start from currentDirectory
    }
    std::stringstream ss(path); //stringstream ss that is set to path
    std::string part; //empty string called part;
    
    while (std::getline(ss, part, '/')){ //dissects ss and adds it to part string until we reach '/'
        if (part == "..") { //if the dissected ss is '..'
            if (target->parent) { //try to move up to its parent
                target = target->parent;
            }
        } 
        else if (part != ""){ //if part isnt empty then 
            bool found = false; //set to false until we find it (if we find it)
            for (auto child : target->children){ //setting each child in target to variable chile
                if (child->name == part && child->isDirectory){ //if its name == part string
                    target = child; //new target set to child so we can move to that directory
                    found = true; //set foudn to true
                    break; //end loop
                }
            }
            if (!found){ //if directory was never found
                throw std::runtime_error("Directory not found."); //throw error
            }
        }
    }
    currentDirectory = target; //setting currentDirectory to where we end up
}

void FileSystem::rm(const std::string& name) {
    for (auto it = currentDirectory->children.begin(); it != currentDirectory->children.end(); ++it){ //iterator it set to children in directory for each iteration
        if ((*it)->name == name){ //if the value (name) of it is the same as child name
            delete *it; //delete node and its children
            currentDirectory->children.erase(it); //remove it pointer from children
            return;
        }
    }
    throw std::runtime_error("File or directory not found"); //otherwise throw error
}

std::string FileSystem::pwd() {
    if (currentDirectory == root){ //if current directory is the root
        return "/";
    }
    std::vector<std::string>Pathway; //creating vector of type string called Pathway
    FileSystemNode* current = currentDirectory; //creating current pointer and setting it to current directory
    while (current != root){ //while current does not == root
    Pathway.push_back(current->name); //adding paths to our pathway vector
        current = current->parent; 
    }
    std::string path; //creating string called path
    for (auto it =Pathway.rbegin(); it !=Pathway.rend(); ++it){ // add pathway to path in reverse
        path += "/" + *it; //adding '/' between each 
    }
    return path + "/"; //adding trailing '/'
}

FileSystemNode* FileSystem::findNode(FileSystemNode* startNode, const std::string& name) {
    if (startNode->name == name) { 
        return startNode;
    }
    for (auto child : startNode->children) { 
        FileSystemNode* found = findNode(child, name); 
        if (found) { 
            return found; 
        }
    }
    return nullptr; 
}

FileSystemNode* FileSystem::find(const std::string& name) {
    return findNode(root, name);
}

std::string FileSystem::displayTree(FileSystemNode* node, std::string indent) {
    std::stringstream ss;
    ss << indent << node->name << (node->isDirectory ? "/" : "") << "\n";
    if (node->isDirectory) {
        for (auto child : node->children) {
            ss << displayTree(child, indent + "  ");
        }
    }
    return ss.str();
}

std::string FileSystem::tree() {
    return displayTree(root, "");
}
